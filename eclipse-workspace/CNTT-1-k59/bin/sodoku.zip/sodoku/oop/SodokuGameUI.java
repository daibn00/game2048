package sodoku.oop;

import sodoku.oop.view.SodokuFrame;

public class SodokuGameUI {

	public static void main(String[] args) {
		SodokuFrame game = new SodokuFrame();
		game.setVisible(true);
	}

}
